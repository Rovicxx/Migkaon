import { initializeApp } from "https://www.gstatic.com/firebasejs/10.12.3/firebase-app.js";
import { getAuth, createUserWithEmailAndPassword, updateProfile } from "https://www.gstatic.com/firebasejs/10.12.3/firebase-auth.js";
import { getFirestore, doc, setDoc } from "https://www.gstatic.com/firebasejs/10.12.3/firebase-firestore.js";

// Your web app's Firebase configuration
const firebaseConfig = {
  apiKey: "AIzaSyCekHj77tQtXYwYaqArBjy6b846ODLodtc",
  authDomain: "tryy-3132a.firebaseapp.com",
  projectId: "tryy-3132a",
  storageBucket: "tryy-3132a.appspot.com",
  messagingSenderId: "670802712817",
  appId: "1:670802712817:web:03adeaf0c10be278de3150"
};

const app = initializeApp(firebaseConfig);
const auth = getAuth(app);
const db = getFirestore(app);

const submit = document.getElementById('submit');
submit.addEventListener("click", function (event){
    event.preventDefault();

    const email = document.getElementById('email').value;
    const password = document.getElementById('password').value;
    const username = document.getElementById('username').value;

    createUserWithEmailAndPassword(auth, email, password)
    .then((userCredential) => {
        // Signed up 
        const user = userCredential.user;

        // Update the user's profile with the username
        updateProfile(user, {
            displayName: username
        }).then(() => {
            // Add the username to Firestore
            setDoc(doc(db, "users", user.uid), {
                email: email,
                username: username
            }).then(() => {
                alert("Account created successfully!");
                window.location.href = "index.html";
            }).catch((error) => {
                console.error("Error adding document: ", error);
                alert("Error adding username to database");
            });
        }).catch((error) => {
            console.error("Error updating profile: ", error);
            alert("Error updating profile");
        });
    })
    .catch((error) => {
        const errorCode = error.code;
        const errorMessage = error.message;
        alert(errorMessage);
    });
});