import { initializeApp } from "https://www.gstatic.com/firebasejs/10.12.3/firebase-app.js";
import { getFirestore, collection, getDocs } from "https://www.gstatic.com/firebasejs/10.12.3/firebase-firestore.js";

// Firebase configuration
const firebaseConfig = {
    apiKey: "AIzaSyATmXoMKttmhS_lZyk-K6cNmw6TgvvgqUw",
    authDomain: "migkaon-ff96a.firebaseapp.com",
    projectId: "migkaon-ff96a",
    storageBucket: "migkaon-ff96a.appspot.com",
    messagingSenderId: "750100665431",
    appId: "1:750100665431:web:2f5be193edb3fb2f7b7f12"
  };

// Initialize Firebase
const app = initializeApp(firebaseConfig);
const db = getFirestore(app);

const ingredientList = document.getElementById('ingredientList');
const recipeContainer = document.getElementById('recipeContainer');
let allRecipes = [];

// Fetch all recipes from Firestore
async function fetchRecipes() {
    recipeContainer.innerHTML = "";
    const recipesRef = collection(db, "recipes");
    const querySnapshot = await getDocs(recipesRef);

    if (querySnapshot.empty) {
        recipeContainer.innerHTML = "<p class='no-recipes-message'>No recipes found.</p>";
    } else {
        allRecipes = [];
        querySnapshot.forEach((doc) => {
            const recipeData = doc.data();
            allRecipes.push(recipeData);
        });
        displayRecipes(allRecipes);
    }
}

// Display the recipes based on filtered data
function displayRecipes(recipes) {
    recipeContainer.innerHTML = "";
    if (recipes.length === 0) {
        recipeContainer.innerHTML = "<p class='no-recipes-message'>No recipes match the selected ingredients.</p>";
    } else {
        recipes.forEach(recipe => {
            const recipeElement = document.createElement('div');
            recipeElement.classList.add('recipe-card');
            recipeElement.innerHTML = `
                <div class="recipe-content">
                    <h3 class="recipe-name">${recipe.name}</h3>
                    <p class="recipe-ingredients"><strong>Ingredients:</strong> ${recipe.ingredients}</p>
                    <p class="recipe-instructions"><strong>Instructions:</strong> ${recipe.instructions}</p>
                </div>
            `;
            recipeContainer.appendChild(recipeElement);
        });
    }
}

// Filter recipes based on selected ingredients
function filterRecipes() {
    const selectedIngredients = Array.from(ingredientList.querySelectorAll('input:checked'))
        .map(checkbox => checkbox.value.toLowerCase());

    if (selectedIngredients.length === 0) {
        displayRecipes(allRecipes); // Show all recipes if no ingredient is selected
    } else {
        const filteredRecipes = allRecipes.filter(recipe =>
            selectedIngredients.every(ingredient =>
                recipe.ingredients.toLowerCase().includes(ingredient)
            )
        );
        displayRecipes(filteredRecipes);
    }
}

// Add event listeners to checkboxes
ingredientList.addEventListener('change', filterRecipes);

// Fetch recipes on page load
fetchRecipes();