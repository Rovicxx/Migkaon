import { initializeApp } from "https://www.gstatic.com/firebasejs/10.12.3/firebase-app.js";
import { getAuth, onAuthStateChanged } from "https://www.gstatic.com/firebasejs/10.12.3/firebase-auth.js";
import { getFirestore, collection, query, where, getDocs, doc, getDoc } from "https://www.gstatic.com/firebasejs/10.12.3/firebase-firestore.js";

// Firebase configuration
const firebaseConfig = {
    apiKey: "AIzaSyCekHj77tQtXYwYaqArBjy6b846ODLodtc",
    authDomain: "tryy-3132a.firebaseapp.com",
    projectId: "tryy-3132a",
    storageBucket: "tryy-3132a.appspot.com",
    messagingSenderId: "670802712817",
    appId: "1:670802712817:web:03adeaf0c10be278de3150"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
const auth = getAuth(app);
const db = getFirestore(app);

const profileNameElement = document.querySelector('.profile-name');
const recipeContainer = document.getElementById('recipeContainer');

// Listen for authentication state changes
onAuthStateChanged(auth, async (user) => {
    if (user) {
        const userId = user.uid;
        console.log("User ID:", userId);

        // Retrieve the username
        const userDoc = await getDoc(doc(db, "users", userId));
        if (userDoc.exists()) {
            const username = userDoc.data().username;
            profileNameElement.textContent = username;

            // Query recipes where the username matches
            const recipesRef = collection(db, "recipes");
            const q = query(recipesRef, where("username", "==", username));
            const querySnapshot = await getDocs(q);

            console.log("Number of recipes found:", querySnapshot.size);

            if (querySnapshot.empty) {
                recipeContainer.innerHTML = "<p>No recipes found.</p>";
            } else {
                querySnapshot.forEach((doc) => {
                    const recipeData = doc.data();
                    console.log("Recipe Data:", recipeData);  // Debugging log to see the data

                    const recipeElement = document.createElement('div');
                    recipeElement.classList.add('recipe');
                    recipeElement.innerHTML = `
                        <h3>${recipeData.name}</h3>
                        <p><strong>Ingredients:</strong> ${recipeData.ingredients}</p>
                        <p><strong>Instructions:</strong> ${recipeData.instructions}</p>
                    `;
                    console.log("Recipe Element:", recipeElement);  // Debugging log to see the element

                    recipeContainer.appendChild(recipeElement);
                });
            }
        } else {
            console.error("No such document!");
        }
    } else {
        console.log("No user is signed in.");
    }
});