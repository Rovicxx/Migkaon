import { initializeApp } from "https://www.gstatic.com/firebasejs/10.12.3/firebase-app.js";
import { getAuth, updatePassword, updateProfile } from "https://www.gstatic.com/firebasejs/10.12.3/firebase-auth.js";
import { getFirestore, doc, setDoc } from "https://www.gstatic.com/firebasejs/10.12.3/firebase-firestore.js";

// Your web app's Firebase configuration
const firebaseConfig = {
    apiKey: "AIzaSyATmXoMKttmhS_lZyk-K6cNmw6TgvvgqUw",
    authDomain: "migkaon-ff96a.firebaseapp.com",
    projectId: "migkaon-ff96a",
    storageBucket: "migkaon-ff96a.appspot.com",
    messagingSenderId: "750100665431",
    appId: "1:750100665431:web:2f5be193edb3fb2f7b7f12"
  };

const app = initializeApp(firebaseConfig);
const auth = getAuth(app);
const db = getFirestore(app);

document.addEventListener('DOMContentLoaded', function() {
    const updateProfileForm = document.getElementById('updateProfileForm');
    updateProfileForm.addEventListener("submit", function (event) {
        event.preventDefault();

        const newPassword = document.getElementById('password').value;
        const confirmPassword = document.getElementById('confirm_password').value;
        const username = document.getElementById('username').value;

        if (newPassword !== confirmPassword) {
            alert("Passwords do not match!");
            return;
        }

        const user = auth.currentUser;

        // Update the user's profile with the username
        updateProfile(user, {
            displayName: username
        }).then(() => {
            // Update password if a new one is provided
            if (newPassword) {
                updatePassword(user, newPassword).then(() => {
                    updateUserData(user.uid, username);
                }).catch((error) => {
                    console.error("Error updating password: ", error);
                    alert("Error updating password");
                });
            } else {
                updateUserData(user.uid, username);
            }
        }).catch((error) => {
            console.error("Error updating profile: ", error);
            alert("Error updating profile");
        });
    });
});

function updateUserData(uid, username) {
    // Add the username to Firestore
    setDoc(doc(db, "users", uid), {
        username: username
    }).then(() => {
        alert("Profile updated successfully!");
        window.location.href = "profile.html";
    }).catch((error) => {
        console.error("Error adding document: ", error);
        alert("Error updating username in database");
    });
}